# IDS completed-flow HTTP export

This fork preserves CICFlowMeter's CSV behavior and additionally publishes each completed live flow to a compatible intrusion-detection backend. Publishing occurs after a flow terminates or reaches its inactivity or maximum-duration timeout; packet capture never waits for the HTTP request.

## Backend contract

At the start of a capture session, CICFlowMeter reads `GET /api/model` and validates `expected_input_columns`. A compatible backend must request the four metadata fields followed by the model's numeric CICFlowMeter features:

- `Flow ID`
- `Src IP`
- `Dst IP`
- `Timestamp`

Each completed flow is then sent as one flat JSON object to `POST /api/flows`. `Label` and `ClassLabel` are never transmitted. A contract mismatch disables HTTP publishing for that capture session while ordinary capture and CSV functionality remain available.

## Configuration

| Environment variable | Default | Purpose |
|---|---|---|
| `IDS_FLOW_ENDPOINT` | `http://127.0.0.1:8000/api/flows` | Completed-flow endpoint |
| `IDS_FLOW_QUEUE_SIZE` | `1000` | Maximum queued flows |
| `IDS_FLOW_TIMEOUT_MS` | `2000` | HTTP connection and read timeout |
| `IDS_FLOW_MAX_RETRIES` | `2` | Retries for connection and server failures |

Publishing uses one FIFO sender thread. Enqueueing never blocks packet capture. If the queue is full, the oldest unsent flow is discarded. Client-side `4xx` responses are not retried.

## Build and test on Windows

Requirements are a JDK, Gradle wrapper access, and a compatible Npcap installation.

```powershell
.\gradlew.bat test
.\gradlew.bat installDist
.\gradlew.bat distZip
```

The generated application is under `build/install/CICFlowMeter`, and the distributable ZIP is under `build/distributions`.

The IDS integration is maintained at <https://github.com/Adam-Zouari/CICFlowMeter> and released from source tag `ids-http-v1.0.0`.
